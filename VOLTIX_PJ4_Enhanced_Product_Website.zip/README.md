# VOLTIX — Enhanced PJ4 Product Launch Website

A responsive three-page smartphone concept storefront built from the supplied `sic_mobile_spec_PJ1.xlsx` workbook.

## Pages
- `index.html` — promotional homepage and featured phone.
- `catalog.html` — complete searchable catalogue of all **413 phones**, with display and rating filters, sorting, and pagination (12 products per page).
- `product.html?id=0` — dynamic product details. The ID in the URL selects any of the 413 product records.

## Supporting files
- `products.json` — all 413 normalized workbook records.
- `styles.css` — responsive styling, CSS product illustrations and light/dark themes.
- `script.js` — catalogue search, filters, sorting, pagination, dynamic detail pages, mobile navigation and theme switch.
- `README.md` — setup instructions.

## Run locally
Keep all files in the same folder. For reliable loading of `products.json`, run a local server:
1. Open a terminal in this folder.
2. Run `python -m http.server 8000`
3. Visit `http://localhost:8000`

VS Code Live Server also works. Directly opening HTML using `file://` may block data loading in some browsers.

## Light / dark mode
Use the sun/moon control in the header. The selected appearance is saved in browser local storage and shared across pages.

## Data and accuracy notes
The featured product is the first workbook record, Voltix Hyper67 5G. The catalogue includes all 413 rows and 11 fields. Numeric prices are formatted with a dollar sign in line with the dollar-prefixed entries in the source; the workbook does not specify a currency code. Ratings are shown as workbook-listed values, not independently verified review scores.

VOLTIX is a fictional concept brand for the assignment. No third-party brand logos or endorsements are used. Unsupported claims such as refresh rate, charging speed, water resistance, review count, warranty or battery endurance are not invented.

The Add to Bag control is a front-end demonstration only; there is no checkout, inventory, payment processing or backend.
